
import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
 ArrowRight,
 Check,
 Eye,
 EyeOff,
 Home,
 LockKeyhole,
 Mail,
 UserRound
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Register() {
 const [form, setForm] = useState({
  username: '',
  fullName: '',
  email: '',
  password: '',
  confirm: ''
 });

 const [show, setShow] = useState(false);
 const [terms, setTerms] = useState(false);
 const [busy, setBusy] = useState(false);
 const [error, setError] = useState('');

 const navigate = useNavigate();
 const { register } = useAuth();

 const set = (key, value) => {
  setForm(old => ({
   ...old,
   [key]: value
  }));
 };

 const strength = useMemo(() => {
  const p = form.password;
  let n = 0;

  if (p.length >= 8) n++;
  if (/[A-Z]/.test(p) && /[a-z]/.test(p)) n++;
  if (/\d/.test(p)) n++;
  if (/[^A-Za-z0-9]/.test(p)) n++;

  return n;
 }, [form.password]);

 const strengthLabel = [
  'Chưa có',
  'Yếu',
  'Trung bình',
  'Khá',
  'Mạnh'
 ];

 async function submit(e) {
  e.preventDefault();
  setError('');

  // Validate username
  if (!/^[a-zA-Z0-9._-]{3,50}$/.test(form.username)) {
   setError(
       'Tên đăng nhập cần 3–50 ký tự, chỉ gồm chữ, số, dấu chấm, gạch dưới hoặc gạch ngang.'
   );
   return;
  }

  // Validate full name
  if (!form.fullName.trim()) {
   setError('Vui lòng nhập họ và tên.');
   return;
  }

  if (form.fullName.trim().length < 2) {
   setError('Họ và tên phải có ít nhất 2 ký tự.');
   return;
  }

  // Validate email
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
   setError('Email chưa đúng định dạng.');
   return;
  }

  // Validate password
  if (form.password.length < 6) {
   setError('Mật khẩu cần tối thiểu 6 ký tự.');
   return;
  }

  if (form.password !== form.confirm) {
   setError('Mật khẩu xác nhận chưa khớp.');
   return;
  }

  // Validate terms
  if (!terms) {
   setError('Vui lòng đồng ý với điều khoản sử dụng.');
   return;
  }

  setBusy(true);

  try {
   await register({
    username: form.username,
    email: form.email,
    password: form.password,
    fullName: form.fullName
   });

   navigate('/login', {
    replace: true,
    state: {
     registered: true
    }
   });
  } catch (err) {
   setError(err.message || 'Không thể tạo tài khoản.');
  } finally {
   setBusy(false);
  }
 }

 return (
     <div className="auth-page register-page">

      {/* Left visual section */}
      <motion.section
          className="auth-visual"
          initial={{ opacity: 0, x: -24 }}
          animate={{ opacity: 1, x: 0 }}
      >
       <Link to="/" className="auth-brand">
                    <span className="brand-mark">
                        <Home size={22} />
                    </span>

        <span>
                        <b>FinHome</b>
                        <small>QUẢN LÝ CHI TIÊU GIA ĐÌNH</small>
                    </span>
       </Link>

       <div className="visual-copy">
                    <span className="eyebrow">
                        BẮT ĐẦU TỪ HÔM NAY
                    </span>

        <h1>
         Một gia đình.
         <br />
         <em>Chung mục tiêu.</em>
        </h1>

        <p>
         Tạo thói quen tài chính tốt hơn, vun đắp những
         kế hoạch lớn cùng những người bạn yêu thương.
        </p>

        <div className="visual-quote">
         <span>“</span>
         <p>
          Không phải bạn kiếm được bao nhiêu, mà là gia
          đình bạn cùng nhau xây dựng được điều gì.
         </p>
        </div>
       </div>

       <div className="visual-orb orb-one" />
       <div className="visual-orb orb-two" />

       <div className="auth-visual-footer">
        © 2026 FinHome
        <span>•</span>
        Cùng nhau vun đắp tương lai
       </div>
      </motion.section>

      {/* Right form section */}
      <section className="auth-form-side">
       <motion.div
           className="auth-form-wrap register-form-wrap"
           initial={{ opacity: 0, y: 18 }}
           animate={{ opacity: 1, y: 0 }}
       >

        {/* Mobile logo: click to return home */}
        <Link
            to="/"
            className="mobile-auth-brand"
            aria-label="Quay về trang chủ FinHome"
        >
                        <span className="brand-mark">
                            <Home size={21} />
                        </span>
         <b>FinHome</b>
        </Link>

        <span className="form-kicker">
                        TẠO KHÔNG GIAN TÀI CHÍNH RIÊNG
                    </span>

        <h2>Tạo tài khoản</h2>

        <p className="form-subtitle">
         Chỉ mất một phút để bắt đầu.
        </p>

        {error && (
            <div className="alert-error" role="alert">
             {error}
            </div>
        )}

        <form className="auth-form" onSubmit={submit}>

         {/* Username */}
         <label htmlFor="username">
          Tên đăng nhập
         </label>

         <div className="input-wrap">
          <UserRound size={18} />

          <input
              id="username"
              autoComplete="username"
              placeholder="Ví dụ: nguyenvana"
              value={form.username}
              onChange={e => set('username', e.target.value)}
          />
         </div>

         {/* Full name */}
         <label htmlFor="fullName">
          Họ và tên
         </label>

         <div className="input-wrap">
          <UserRound size={18} />

          <input
              id="fullName"
              autoComplete="name"
              placeholder="Tên hiển thị của bạn"
              value={form.fullName}
              onChange={e => set('fullName', e.target.value)}
          />
         </div>

         {/* Email */}
         <label htmlFor="email">
          Email
         </label>

         <div className="input-wrap">
          <Mail size={18} />

          <input
              id="email"
              type="email"
              autoComplete="email"
              placeholder="ban@example.com"
              value={form.email}
              onChange={e => set('email', e.target.value)}
          />
         </div>

         {/* Password */}
         <label htmlFor="newPassword">
          Mật khẩu
         </label>

         <div className="input-wrap">
          <LockKeyhole size={18} />

          <input
              id="newPassword"
              type={show ? 'text' : 'password'}
              autoComplete="new-password"
              placeholder="Tối thiểu 6 ký tự"
              value={form.password}
              onChange={e => set('password', e.target.value)}
          />

          <button
              type="button"
              className="input-action"
              onClick={() => setShow(!show)}
              aria-label={
               show ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'
              }
          >
           {show
               ? <EyeOff size={18} />
               : <Eye size={18} />
           }
          </button>
         </div>

         {/* Password strength */}
         <div className="strength-row">
          <div className="strength-bars">
           {[1, 2, 3, 4].map(i => (
               <span
                   key={i}
                   className={strength >= i ? 'filled' : ''}
               />
           ))}
          </div>

          <small>
           Độ mạnh:
           {' '}
           <b>{strengthLabel[strength]}</b>
          </small>
         </div>

         {/* Confirm password */}
         <label htmlFor="confirm">
          Xác nhận mật khẩu
         </label>

         <div className="input-wrap">
          <LockKeyhole size={18} />

          <input
              id="confirm"
              type={show ? 'text' : 'password'}
              autoComplete="new-password"
              placeholder="Nhập lại mật khẩu"
              value={form.confirm}
              onChange={e => set('confirm', e.target.value)}
          />

          {form.confirm && (
              <span
                  className={`match-icon ${
                      form.confirm === form.password
                          ? 'match'
                          : 'mismatch'
                  }`}
              >
                                    {form.confirm === form.password
                                        ? <Check size={17} />
                                        : <span>!</span>
                                    }
                                </span>
          )}
         </div>

         {form.confirm && form.confirm !== form.password && (
             <small className="field-error">
              Mật khẩu chưa khớp.
             </small>
         )}

         {/* Terms */}
         <label className="check-row terms-row">
          <input
              type="checkbox"
              checked={terms}
              onChange={e => setTerms(e.target.checked)}
          />

          <span>
                                Tôi đồng ý với{' '}
           <a
               href="#terms"
               onClick={e => {
                e.preventDefault();
                setError(
                    'Điều khoản sử dụng: sử dụng tài khoản đúng mục đích và chỉ nhập dữ liệu tài chính mà bạn có quyền quản lý.'
                );
               }}
           >
                                    điều khoản sử dụng
                                </a>
           {' '}của FinHome.
                            </span>
         </label>

         {/* Submit */}
         <button
             className="btn-primary auth-submit"
             disabled={busy}
         >
          {busy ? (
              <>
               <span className="button-spinner" />
               Đang tạo tài khoản…
              </>
          ) : (
              <>
               Tạo tài khoản
               <ArrowRight size={18} />
              </>
          )}
         </button>
        </form>

        <p className="auth-switch">
         Đã có tài khoản?
         {' '}
         <Link to="/login">
          Đăng nhập
          <ArrowRight size={15} />
         </Link>
        </p>

       </motion.div>
      </section>
     </div>
 );
}
