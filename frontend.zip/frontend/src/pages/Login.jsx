
import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  Eye,
  EyeOff,
  Home,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Sparkles,
  Wallet
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const { signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  async function submit(e) {
    e.preventDefault();
    setError('');

    if (!identifier.trim() || !password) {
      setError('Vui lòng nhập tên đăng nhập/email và mật khẩu.');
      return;
    }

    setBusy(true);

    try {
      await signIn(identifier.trim(), password, remember);

      navigate(
          location.state?.from?.pathname || '/app/dashboard',
          { replace: true }
      );
    } catch (err) {
      setError(
          err.message || 'Đăng nhập thất bại. Vui lòng thử lại.'
      );
    } finally {
      setBusy(false);
    }
  }

  return (
      <div className="auth-page">

        {/* Left visual section */}
        <motion.section
            className="auth-visual"
            initial={{ opacity: 0, x: -24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.55 }}
        >
          <Link to="/" className="auth-brand">
                    <span className="brand-mark">
                        <Home size={22} />
                    </span>

            <span>
                        <b>FinHome</b>
                        <small>QUẢN LÝ CHI TIÊU GIA ĐÌNH</small>
                    </span>
          </Link>

          <div className="visual-copy">
                    <span className="eyebrow">
                        <Sparkles size={14} />
                        TÀI CHÍNH THÔNG MINH, SỐNG AN TÂM
                    </span>

            <h1>
              Cùng nhau xây dựng
              <br />
              <em>tương lai thịnh vượng.</em>
            </h1>

            <p>
              Mọi mục tiêu lớn đều bắt đầu từ những quyết định
              tài chính nhỏ mỗi ngày.
            </p>

            <div className="visual-stat-row">
              <div className="visual-stat">
                            <span className="stat-icon">
                                <Wallet size={18} />
                            </span>

                <span>
                                <b>Rõ ràng từng khoản chi</b>
                                <small>Chủ động quản lý ngân sách</small>
                            </span>
              </div>

              <div className="visual-stat">
                            <span className="stat-icon">
                                <ShieldCheck size={18} />
                            </span>

                <span>
                                <b>An tâm cùng gia đình</b>
                                <small>Cùng nhau tiến tới mục tiêu</small>
                            </span>
              </div>
            </div>
          </div>

          <div className="visual-orb orb-one" />
          <div className="visual-orb orb-two" />

          <div className="auth-visual-footer">
            © 2026 FinHome
            <span>•</span>
            Tổ ấm vững vàng, tài chính vững chắc
          </div>
        </motion.section>

        {/* Right form section */}
        <section className="auth-form-side">
          <motion.div
              className="auth-form-wrap"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.12, duration: 0.5 }}
          >

            {/* Mobile logo: click to return home */}
            <Link
                to="/"
                className="mobile-auth-brand"
                aria-label="Quay về trang chủ FinHome"
            >
                        <span className="brand-mark">
                            <Home size={21} />
                        </span>
              <b>FinHome</b>
            </Link>

            <span className="form-kicker">
                        CHÀO MỪNG BẠN TRỞ LẠI
                    </span>

            <h2>Đăng nhập</h2>

            <p className="form-subtitle">
              Tiếp tục hành trình quản lý tài chính gia đình.
            </p>

            {error && (
                <div className="alert-error" role="alert">
                  {error}
                </div>
            )}

            <form onSubmit={submit} className="auth-form">

              <label htmlFor="identifier">
                Tên đăng nhập hoặc Email
              </label>

              <div className="input-wrap">
                <Mail size={18} />

                <input
                    id="identifier"
                    autoComplete="username"
                    placeholder="Nhập tên đăng nhập hoặc email"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                />
              </div>

              <div className="label-row">
                <label htmlFor="password">
                  Mật khẩu
                </label>
              </div>

              <div className="input-wrap">
                <LockKeyhole size={18} />

                <input
                    id="password"
                    type={show ? 'text' : 'password'}
                    autoComplete="current-password"
                    placeholder="Nhập mật khẩu"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />

                <button
                    type="button"
                    className="input-action"
                    onClick={() => setShow(!show)}
                    aria-label={
                      show ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'
                    }
                >
                  {show
                      ? <EyeOff size={18} />
                      : <Eye size={18} />
                  }
                </button>
              </div>

              <label className="check-row">
                <input
                    type="checkbox"
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                />
                <span>Ghi nhớ phiên đăng nhập</span>
              </label>

              <button
                  className="btn-primary auth-submit"
                  disabled={busy}
              >
                {busy ? (
                    <>
                      <span className="button-spinner" />
                      Đang đăng nhập…
                    </>
                ) : (
                    <>
                      Đăng nhập
                      <ArrowRight size={18} />
                    </>
                )}
              </button>
            </form>

            <p className="auth-switch">
              Chưa có tài khoản?
              {' '}
              <Link to="/register">
                Đăng ký ngay
                <ArrowRight size={15} />
              </Link>
            </p>

            <div className="secure-note">
              <ShieldCheck size={15} />
              Thông tin của bạn được bảo vệ an toàn
            </div>

          </motion.div>
        </section>
      </div>
  );
}
