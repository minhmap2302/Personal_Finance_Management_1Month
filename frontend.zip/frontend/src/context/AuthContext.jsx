
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';

import { useNavigate } from 'react-router-dom';
import api, { apiError, responseData } from '../lib/api';
import { useToast } from './ToastContext';

const AuthContext = createContext(null);

const ACCESS = 'pfm.accessToken';
const REFRESH = 'pfm.refreshToken';
const USER = 'pfm.user';
const LEGACY_ACTIVE_FAMILY = 'pfm.activeFamilyId';

function getStoredUser() {
  try {
    return JSON.parse(
        localStorage.getItem(USER) ||
        sessionStorage.getItem(USER) ||
        'null',
    );
  } catch {
    return null;
  }
}

function saveUser(userData) {
  const storage = localStorage.getItem(ACCESS)
      ? localStorage
      : sessionStorage;

  storage.setItem(USER, JSON.stringify(userData));
}

export function AuthProvider({ children }) {
  const navigate = useNavigate();
  const showToast = useToast();

  const [token, setToken] = useState(
      () =>
          localStorage.getItem(ACCESS) ||
          sessionStorage.getItem(ACCESS),
  );

  const [user, setUser] = useState(getStoredUser);
  const [loading, setLoading] = useState(true);

  const isAuthenticated = Boolean(token && user);

  // Khi refresh thất bại, api.js phát sự kiện này.
  useEffect(() => {
    const handleAuthExpired = () => {
      setToken(null);
      setUser(null);
      setLoading(false);

      showToast(
          'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.',
          'warning',
          4000,
      );

      navigate('/login', { replace: true });
    };

    window.addEventListener('pfm:auth-expired', handleAuthExpired);

    return () => {
      window.removeEventListener(
          'pfm:auth-expired',
          handleAuthExpired,
      );
    };
  }, [navigate, showToast]);

  // Khôi phục và xác minh phiên đăng nhập khi mở ứng dụng.
  useEffect(() => {
    let active = true;

    const restoreSession = async () => {
      const storedToken =
          localStorage.getItem(ACCESS) ||
          sessionStorage.getItem(ACCESS);

      if (!storedToken) {
        if (active) setLoading(false);
        return;
      }

      try {
        const response = await api.get('/api/v1/users/me');
        const userData = responseData(response);

        if (!active) return;

        setUser(userData);
        saveUser(userData);
      } catch (error) {
        // Nếu server lỗi mạng, không tự ý xóa phiên đã lưu.
        // Nếu refresh thất bại, api.js đã phát sự kiện hết hạn.
        if (active && error?.response?.status === 401) {
          setToken(null);
          setUser(null);
        }
      } finally {
        if (active) setLoading(false);
      }
    };

    restoreSession();

    return () => {
      active = false;
    };
  }, []);

  const login = useCallback(
      (nextToken, userData, refreshToken, remember = true) => {
        [localStorage, sessionStorage].forEach((storage) => {
          [ACCESS, REFRESH, USER].forEach((key) => {
            storage.removeItem(key);
          });
        });

        localStorage.removeItem(LEGACY_ACTIVE_FAMILY);
        sessionStorage.removeItem(LEGACY_ACTIVE_FAMILY);

        const storage = remember ? localStorage : sessionStorage;

        storage.setItem(ACCESS, nextToken);

        if (refreshToken) {
          storage.setItem(REFRESH, refreshToken);
        }

        storage.setItem(USER, JSON.stringify(userData || {}));

        setToken(nextToken);
        setUser(userData || {});

        showToast(
            'Đăng nhập thành công. Chào mừng bạn quay trở lại!',
            'success',
            3500,
        );
      },
      [showToast],
  );

  const logout = useCallback(
      async (redirect = true) => {
        const refreshToken =
            localStorage.getItem(REFRESH) ||
            sessionStorage.getItem(REFRESH);

        try {
          if (token) {
            await api.post(
                '/api/v1/auth/logout',
                refreshToken ? { refreshToken } : {},
            );
          }
        } catch {
          // Đăng xuất cục bộ vẫn phải thực hiện nếu server lỗi.
        }

        [localStorage, sessionStorage].forEach((storage) => {
          [ACCESS, REFRESH, USER, LEGACY_ACTIVE_FAMILY].forEach((key) => {
            storage.removeItem(key);
          });
        });

        setToken(null);
        setUser(null);

        showToast(
            'Bạn đã đăng xuất khỏi FinHome.',
            'success',
            3500,
        );

        if (redirect) {
          navigate('/login', { replace: true });
        }
      },
      [navigate, token, showToast],
  );

  const register = useCallback(
      async (userData) => {
        try {
          const response = await api.post(
              '/api/v1/auth/register',
              userData,
          );

          showToast(
              'Đăng ký tài khoản thành công. Hãy đăng nhập để tiếp tục.',
              'success',
              3800,
          );

          return responseData(response);
        } catch (error) {
          throw apiError(error);
        }
      },
      [showToast],
  );

  const signIn = useCallback(
      async (identifier, password, remember = true) => {
        try {
          const response = await api.post('/api/v1/auth/login', {
            usernameOrEmail: identifier,
            username: identifier,
            password,
          });

          const data = responseData(response);

          if (!data.accessToken || !data.refreshToken) {
            throw {
              message:
                  'API đăng nhập không trả về đủ accessToken và refreshToken.',
            };
          }

          login(
              data.accessToken,
              data.user,
              data.refreshToken,
              remember,
          );

          return data;
        } catch (error) {
          throw error?.message && !error?.response
              ? error
              : apiError(error);
        }
      },
      [login],
  );

  const value = useMemo(
      () => ({
        user,
        token,
        loading,
        isAuthenticated,
        login,
        logout,
        register,
        signIn,
      }),
      [
        user,
        token,
        loading,
        isAuthenticated,
        login,
        logout,
        register,
        signIn,
      ],
  );

  return (
      <AuthContext.Provider value={value}>
        {children}
      </AuthContext.Provider>
  );
};

export default AuthProvider;

export function useAuth() {
  const value = useContext(AuthContext);

  if (!value) {
    throw new Error('useAuth must be used within AuthProvider');
  }

  return value;
}
